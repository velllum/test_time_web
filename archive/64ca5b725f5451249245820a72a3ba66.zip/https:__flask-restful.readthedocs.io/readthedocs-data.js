var READTHEDOCS_DATA = {
    project: "flask-restful",
    version: "latest",
    language: "en",
    programming_language: "py",
    subprojects: {},
    canonical_url: "https://flask-restful.readthedocs.io/en/latest/",
    theme: "flask",
    builder: "sphinx",
    docroot: "/docs/",
    source_suffix: ".rst",
    api_host: "https://readthedocs.org",
    proxied_api_host: "https://readthedocs.org",
    commit: "5a6d00e8",
    ad_free: false,

    global_analytics_code: "UA-17997319-1",
    user_analytics_code: null
};

